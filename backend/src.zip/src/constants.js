module.exports = {
    userStatus:["INVITED","ACTIVE","INACTIVE","REGISTER"],
    userType:["ADMIN","MODERATOR","USER"],
}
